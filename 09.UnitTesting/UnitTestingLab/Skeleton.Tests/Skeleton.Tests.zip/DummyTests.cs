﻿using NUnit.Framework;

namespace Skeleton.Tests
{
    [TestFixture]
    public class DummyTests
    {
        [Test]
        public void AttackedDummyLosesHealth()
        {
            Axe axe = new Axe(10,10);
            Dummy dummy = new Dummy(10,10);
            axe.Attack(dummy);
            Assert.That(dummy.Health, Is.EqualTo(0));
        }

        [Test]
        public void DeadDummyThrowsException()
        {
            Axe axe = new Axe(10, 10);
            Dummy dummy = new Dummy(10, 10);
            dummy.TakeAttack(axe.AttackPoints);
            Assert.That(() => { dummy.TakeAttack(axe.AttackPoints); }, Throws.InvalidOperationException, "Dummy is dead.");
        }

        [Test]
        public void CanDeadDummyGiveXP()
        {
            Axe axe = new Axe(10, 10);
            Dummy dummy = new Dummy(11, 10);
            dummy.TakeAttack(axe.AttackPoints);
            Assert.That(() => { dummy.GiveExperience(); }, Throws.InvalidOperationException, "Target is not dead.");
        }

        [Test]
        public void CantDeadDummyGiveXP()
        {
            Axe axe = new Axe(10, 10);
            Dummy dummy = new Dummy(10, 10);
            dummy.TakeAttack(axe.AttackPoints);
            Assert.That(dummy.GiveExperience(), Is.EqualTo(10), "Return experience points");
        }

    }
}
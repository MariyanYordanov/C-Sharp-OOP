﻿namespace EasterRaces.Repositories.Entities
{
    internal interface IRepository
    {
    }
}
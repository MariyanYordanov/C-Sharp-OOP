﻿namespace Gym.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}

﻿namespace Collection.Interfaces
{
    public interface IAddCollection
    {
        int Add(string input);
    }
}

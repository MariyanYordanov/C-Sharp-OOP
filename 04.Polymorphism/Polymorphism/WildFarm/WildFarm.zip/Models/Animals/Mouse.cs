﻿namespace WildFarm.Models.Animals
{
    using Contracts;
    using Food;
    public class Mouse : Mammal
    {
        public Mouse(string name, double weight, string livingRegion)
            : base(name, weight, livingRegion)
        {
        }

        public override string Sound => "Squeak";

        public override void Eat(IFood food)
        {
            if (food is Fruit || food is Vegetable)
            {
                this.FoodEaten += food.Quantity;
                this.Weight += food.Quantity * 0.10;
            }
            else
            {
                ThrowInvalidOperationExceptionForFood(this, food);
            }

        }
        public override string ToString()
        {
            return base.ToString() + $" [{Name}, {Weight}, {LivingRegion}, {FoodEaten}]";
        }
    }
}

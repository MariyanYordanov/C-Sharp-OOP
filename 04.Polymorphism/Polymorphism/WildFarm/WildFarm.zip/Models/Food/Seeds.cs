﻿namespace WildFarm.Models.Food
{
    public class Seeds : Food
    {
        public Seeds(int quantity) : base(quantity)
        {
        }

    }
}

﻿namespace _3._Raiding.Models
{
    public class Paladin : BaseHero
    {
        public Paladin(string name) 
            : base(name, 100)
        {
        }
    }
}

﻿namespace _3._Raiding.Contracts
{
   public  interface ICastAbilitable
    {
        public string CastAbility();
    }
}

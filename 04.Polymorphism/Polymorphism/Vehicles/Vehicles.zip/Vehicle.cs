﻿namespace Vehicles
{
    public abstract class Vehicle : IVehicle
    {
        private double airConditioner;
        private double fuelConsumption;
        private double fuelQuantity;
        protected Vehicle(double fuelQuantity, double fuelConsumption)
        {
            FuelQuantity = fuelQuantity;
            FuelConsumption = fuelConsumption;
        }
       
        public double FuelQuantity
        {
            get => fuelQuantity;
            private set
            {
                Validator.ValidateValue(value);
                fuelQuantity = value;
            }
        }
        public double FuelConsumption
        {
            get => fuelConsumption;
            private set
            {
                Validator.ValidateValue(value);
                fuelConsumption = value;
            }
        }

        private double AirConditioner { get => airConditioner; set => airConditioner = value; }

        public string Driving(double distance)
        {

            if (GetType().Name == "Truck")
            {
                this.AirConditioner = 1.6; 
            }
            else if (GetType().Name == "Car")
            {
                this.AirConditioner = 0.9; 
            }

            double neededFuel = (FuelConsumption + this.AirConditioner) * distance;
            if (neededFuel <= FuelQuantity)
            {
                FuelQuantity -= neededFuel;
                return $"{GetType().Name} travelled {distance} km";
            }
            else
            {
                return $"{GetType().Name} needs refueling";
            }
        }

        public void Refueling(double litres)
        {
            if (GetType().Name == "Truck")
            {
                FuelQuantity += litres * 0.95;
            }
            else if (GetType().Name == "Car")
            {
                FuelQuantity += litres;
            }
        }

        public override string ToString()
        {
            return $" {FuelQuantity:F2}";
        }

       
    }
}

﻿namespace Vehicles
{
    public class Truck : Vehicle 
    {
        
        public Truck(double fuelQuantity, double fuelConsumption) : base(fuelQuantity, fuelConsumption)
        {
        }

        public override string ToString()
        {
            return $"{GetType().Name}:" + base.ToString();
        }

    }
}

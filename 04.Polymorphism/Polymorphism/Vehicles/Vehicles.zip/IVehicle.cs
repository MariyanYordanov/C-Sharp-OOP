﻿namespace Vehicles
{
    public interface IVehicle
    {
        
        double FuelConsumption { get; }
        double FuelQuantity { get; }

       string Driving(double distance);
        void Refueling(double litres);
    }
}
